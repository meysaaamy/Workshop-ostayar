plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.workshop.ledger"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.workshop.ledger"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.0.1-dev"
    }
    // A development install must not overwrite the original application.
    buildTypes.getByName("debug") { applicationIdSuffix = ".dev"; versionNameSuffix = "-debug" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(project(":domain"))
    implementation(project(":data"))
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
